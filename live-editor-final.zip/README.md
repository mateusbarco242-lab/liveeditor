# Live Editor Avançado

Editor HTML/CSS/JS com:
- Tema claro/escuro
- Botão de copiar e baixar
- Salvamento automático (localStorage)
- Divisor redimensionável (drag)
- PWA: manifest + service worker
- Atalhos: Ctrl/Cmd+S salvar, Ctrl/Cmd+B identar seleção

## Como publicar no GitHub Pages

1. Crie um repositório público (ex: `live-editor`)
2. Faça upload dos arquivos:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icon-192.png` (opcional)
   - `icon-512.png` (opcional)
3. Vá em Settings → Pages → Source = `main` branch → root (`/`) → Save

Site ficará disponível em: `https://SEU_USUARIO.github.io/live-editor/`

## Comandos git (exemplo)
```bash
git init
git add .
git commit -m "Initial commit — Live Editor"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/live-editor.git
git push -u origin main
```
